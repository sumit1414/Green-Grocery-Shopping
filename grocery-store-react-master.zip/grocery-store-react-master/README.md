# A Grocery Store built with React 😋️

This project is a React version of this [tutorial](https://www.youtube.com/watch?v=lCCN_lkl3Xw)

## What was used:
- [React](https://pt-br.reactjs.org/)
- [Font Awesome](https://fontawesome.com/)
- [Swiper](https://swiperjs.com/react)

Click [here](https://grocery-store-react.netlify.app/) to visit the page!

![image](https://media.discordapp.net/attachments/402972272870162435/896064057503809537/Screenshot_from_2021-10-08_12-58-11.png?width=917&height=458)

Credits to [Mr. Web Designer](https://www.youtube.com/channel/UCKwgH3vASrD2brd1l2m6NHw).

Made with ❤️ by [vdsou](https://github.com/vdsou)